<?php include 'include/head.php' ?>
<body>
  <?php include 'include/header.php' ?>

  

  <div class="site-section">
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center">
          <span class="icon-check_circle display-3 text-success"></span>
          <h2 class="display-3 text-black">Obrigado pela Compra!</h2>
          <a href="boleto.php"><p class="lead mb-5">Boleto para Pagamento</p></a>
          <p> ----N° do comprovante----</p>
          <p id="demo"></p>

          <form id="form1" runat="server">  
            <div>                
            </div>   
            <h2 align="center"> Comprovante:</h2>  
            <table id="table1"; cellspacing="5px" cellpadding="5%"; align="center">  
             <tr>  
              <td  align="right" class="style1">N° Pedido:</td>  
              <td class="style1"><output type="text" name="Job Title" /></td>  
            </tr>  
              
            <tr>  
              <td align="right">Endereço:</td>  
              <td><output type="text" name="Company Name" /></td>  
            </tr>  
            <tr>  
              <td align="right">Cep:</td>  
              <td><output type="text" name="Contact number" /></td>  
            </tr>  
            <tr>  
              <td align="right">Valor Total:</td>  
              <td><output type="text" name="Contact person" /></td>  
            </tr>  
            <tr>  
              <td valign="top" align="right">Descrição:</td>  
              <td><output type="text" name="Email" /></td>  
            </tr>  
            </table>   
          </form>
          
        </div>
      </div>
    </div>
  </div>
  <?php include 'include/footer.php' ?>
</body>
</html>