	<?php

		include_once '../../DataBase/conexao.php';
		include_once 'detailsProducts.php';

		function detalhosProduto($dados){
			$datil = new detailsProducts();
			$result = $detail->cadastrarDetalhes($_POST);

			if ($result){
				echo "
					<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=../../thankyou.php'>
					<script type=\"text/javascript\">
						alert(\"Sucesso!\");
					</script>
					";
			}else{
	    		echo "Erro ao cadastrar";
	    		$result->errorInfo();
			}
		}
	?>