<?php

class DetailsController {

    public function allDetails() {
        $conexao = new Conexao();
        $conexao = $conexao->conexao();
        $stmt = $conexao->prepare("SELECT * FROM details;");
        $stmt->execute();
        $details = $stmt->fetchAll();
        $stmt = null;
        return $details;
    }

    public function detailsProduts($dados) {
        $conexao = new Conexao();
        $conexao = $conexao->conexao();
        if($dados["c_diff_endereco"]==null){
            $stmt = $conexao->prepare('INSERT INTO details(endereco, cep, valor, texto) VALUES(:eendereco, :ecep, :evalor, :enotes);');
            $stmt->bindParam(':eendereco', $dados['c_diff_endereco']);
            $stmt->bindParam(':ecep', $dados['c_diff_cep']);
            $stmt->bindParam(':evalor', $dados['total']);
            $stmt->bindParam(':enotes', $dados['c_order_notes']);
            $result =  $stmt->execute();
            return $result;
        }else{
            $stmt = $conexao->prepare('INSERT INTO details(endereco, cep, valor, texto) VALUES(:eendereco, :ecep, :evalor, :enotes);');
            $stmt->bindParam(':eendereco', $dados['c_endereco']);
            $stmt->bindParam(':ecep', $dados['c_cep']);
            $stmt->bindParam(':evalor', $dados['total']);
            $stmt->bindParam(':enotes', $dados['c_notes']);
            $result =  $stmt->execute();
            return $result;
        }
        


    }    


}

?>